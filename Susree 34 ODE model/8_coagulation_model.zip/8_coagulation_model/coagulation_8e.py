#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 29 16:33:17 2021

@author: zen
"""

## Required import statements for program functionality.

import torch
import numpy as np
from scipy import io
import learner as ln
from learner.utils import mse, grad

class RBCData(ln.Data):
    
    ## Instantiates the dataset object.
    def __init__(self):
        super(RBCData, self).__init__()
        self.__init_data()
        
    ## Loads matlab files and normalizes x values.
    def generate(self):
        t = io.loadmat('data/coagulation_t.mat')['t']  # Change to /t2 for 180s range; /t2100s for 100s range
        x = io.loadmat('data/coagulation_dynamics.mat')['y'] # Change to /x2 for 180s range; /x2100s for 100s range
        
        # Add noise
        #noise = np.random.normal(0, 0.05, [297, 15])   # Change to [318, 15] for 180s range
        #x = x + noise
        # Done adding noise
        
        norm = np.max(x, axis = 0)[None,:] + 1e-8
        x = x / norm
        #norm[:,3] = norm[:,3]/10
        #x[:,3] = x[:,3] * 10
        # Add noise attempt 2 
        #noise = np.random.normal(0, 0.05, [297, 15]) # Change to [318, 15] for 180s range
        #x = x + noise
        # Done adding noise
        
        # Add noise attempt 3 - Random Seed
        #noise = np.random.normal(0, x.std(), [318,15]) * .05 # Change to [297, 15] for 180s range
        #x = x + noise
        # Done adding noise
        
        # Add noise - Set Seed
        #torch.manual_seed(0)
        #noisegen = torch.normal(0, x.std(), [297,15]) * .05 # Change to [318, 15] for 180s range; [297, 15] for 100s range
        #noise = noisegen.numpy()
        #x = x + noise
        # Done adding noise
        
        return t, x, norm
    
    ## Instantiates the dataset object.
    def __init_data(self):
        self.X_train, self.y_train, self.norm = self.generate()
        self.X_test, self.y_test, _ = self.generate()
        
## This class takes in a neural net that optimizes based on minimizing the loss.
class RBCPINN(ln.nn.LossNN):
    
    ## Initializes the neural net.
    def __init__(self, net, norm, k_index, k_list, k_norm, x_index, lam1 = 1, lam2 = 1, lam3 = 1): 
        super(RBCPINN, self).__init__()
        self.net = net
        self.norm = norm
        self.k_index = k_index
        self.k_list = k_list
        self.k_norm = k_norm
        self.x_index = x_index
        self.lam1 = lam1
        self.lam2 = lam2
        self.lam3 = lam3
        self.k_dim = 22
        self.K = self.__init_params()
        
    ## 
    def criterion(self, t, x):
        t = t.requires_grad_(True)
        x_pred = self.net(torch.cat([t,torch.exp(-t)],dim=-1))
        x_t = grad(x_pred, t).squeeze()
        #print(x_pred.device, x.device, self.x_index, x.shape, x_pred.shape)
        MSE2 = mse(x_pred[...,self.x_index], x[...,self.x_index])
        MSE3 = mse(x_pred[[0,-1]], x[[0,-1]])
        x_pred[...,self.x_index] = x[...,self.x_index]
       # MSE1 = mse(x_t[:,3], self.f(x_pred)[:,3])
        MSE1 = mse(x_t, self.f(x_pred))
        #return self.lam2 * MSE2 + self.lam1 * (MSE1 + MSE3)
        return self.lam2 * MSE2 + self.lam1 * MSE1 + self.lam3 * MSE3
    
    ## Defines the governing ODES
    def f(self, x):
        dx = []
        K = [torch.exp(k) for k in self.K]
        K = [K[i] * self.k_norm[i] for i in range(self.k_dim)]
        
        norm = torch.tensor(self.norm, dtype = self.dtype, device = self.device)
        x = x * norm
        #print(torch.sum(x))

        # coagulation 8 ODE equations
        # XIa, IXa, Xa, II, IIa, VIIIa, APC, Va, Ia, Z, W
        dx.append(-K[21]*x[...,0])
        dx.append(K[0]*x[...,0] - K[1]*x[...,1])
        dx.append(K[7]*x[...,1] + K[7]*((x[...,5]*x[...,1])/x[...,7]) - K[14]*x[...,2])
        dx.append(K[11]*x[...,2]*((x[...,4])/(x[...,4] + K[12])) + K[11]*((x[...,6]*x[...,2])/x[...,7])*((x[...,4])/(x[...,4] + K[12])) - K[16]*x[...,3])
        dx.append(-K[11]*x[...,2]*((x[...,4])/(x[...,4] + K[12])) - K[11]*((x[...,6]*x[...,2])/x[...,7])*((x[...,4])/(x[...,4] + K[12])))
        dx.append(K[2]*x[...,3] - K[3]*x[...,5] - K[4]*x[...,7]*(x[...,5]+((x[...,5]*x[...,1])/x[...,7])))
        dx.append(K[5]*x[...,3] - K[6]*x[...,6] - K[4]*x[...,7]*(x[...,6]+((x[...,7]*x[...,2])/x[...,7])))
        dx.append(K[17]*x[...,3] - K[18]*x[...,7])
        dx.append(K[19]*x[...,3])
        #dx.append(torch.zeros(x.shape[:-1],dtype=self.dtype,device=self.device))
        #dx.append(torch.zeros(x.shape[:-1],dtype=self.dtype,device=self.device))
        dx = torch.stack(dx, dim = -1)
        #print(torch.sum(dx), K)
        return dx
    ## 
    def predict(self, t, returnnp=False):
        x = self.net(torch.cat([t,torch.exp(-t)],dim=-1))
        if returnnp:
            x = x.detach().cpu().numpy()
        return x
    
    ## Returns parameters
    def __init_params(self):
        params = torch.nn.ParameterList()
        for i in range(self.k_dim):
            if i not in self.k_index:
                ki = torch.tensor(self.k_list[i], dtype = self.dtype, device = self.device)
                params.append(torch.nn.Parameter(torch.log(ki), requires_grad = False))
            else:
                ki = torch.randn(1, dtype = self.dtype, device = self.device)[0]
                params.append(torch.nn.Parameter(ki, requires_grad = True))
        return params  
    
def callback(data, net):
    t, x = data.get_batch(None)
    t = t.requires_grad_(True)
    x_pred = net.net(torch.cat([t,torch.exp(-t)],dim=-1))
    x_t = grad(x_pred, t).squeeze()
    MSE2 = mse(x_pred[...,net.x_index], x[...,net.x_index])
    MSE3 = mse(x_pred[[0,-1]], x[[0,-1]])
    x_pred[...,net.x_index] = x[...,net.x_index]
    MSE1 = mse(x_t, net.f(x_pred))
    MSE_list = [MSE1.item(),MSE2.item(),MSE3.item()]
    for i in net.x_index:
        MSE = mse(x_pred[...,i], x[...,i])
        MSE_list.append(MSE.item())
    for i in range(x_pred.shape[-1]):
        MSE = mse(x_t[...,i], net.f(x_pred)[...,i])
        MSE_list.append(MSE.item())
    return MSE_list

def plot(data, net):
    import matplotlib.pyplot as plt
    t, y = data.get_batch_test(None)
    x = net.predict(t, True)
    y = y.detach().cpu().numpy()
    x = x * data.norm
    y = y * data.norm
    name_list = ['XIa','IXa', 'Xa', 'IIa', 'II', 'VIIIa', 'Va', 'APC', 'Ia'] # output pdf format
    plt.figure(figsize=[4.8 * 5, 4.8 * 3])
    for i in range(len(name_list)):
        plt.subplot(3,5,i+1)
        plt.plot(t.detach().cpu().numpy(), x[...,i], 'r', label = 'PINN')
        plt.plot(t.detach().cpu().numpy(), y[...,i], 'b', label = 'Ground Truth')
        if i in net.x_index:
            plt.plot(t.detach().cpu().numpy(), y[...,i], 'b.', label = 'Data')
        plt.title('{} (X{})'.format(name_list[i], i+1), fontsize=18)
        plt.legend()
    plt.tight_layout()
    plt.savefig('pinn.pdf')
    k_pred = np.array([np.exp(k.item()) for k in net.K])[net.k_index]
    k_true = np.array(net.k_list)[net.k_index]
    np.savetxt('k_learned', k_pred)
    np.savetxt('k_true', k_true)
    
def plot2(path):
    import matplotlib.pyplot as plt
    loss = np.loadtxt('outputs/'+path+'/loss.txt')
    if len(loss.shape) == 1:
        loss = loss.reshape([1,-1])
    iters = loss[:,0]
    plt.figure(figsize = [6.4, 4.8*3])
    plt.subplot(311)
    plt.plot(iters, loss[:,3], label = r'$L_{ode}$')
    plt.legend()
    plt.yscale('log',base=10)
    plt.subplot(312)
    plt.plot(iters, loss[:,4], label = r'$L_{data}$')
    plt.legend()
    plt.yscale('log',base=10)
    plt.subplot(313)
    plt.plot(iters, loss[:,5], label = r'$L_{aux}$')
    plt.yscale('log',base=10)
    plt.legend()
    # The rest columns of loss are the individual losses, you can plot them below
    plt.savefig('loss.pdf')
    plt.tight_layout()

def main():
    device = 'gpu' # 'cpu' or 'gpu' 'cuda'
    # fnn
    depth = 5
    width = 60
    activation = 'tanh'  # Standard is tanh
    # training
    lr = 0.001  # 0.001
    iterations = 50000   # Set to 0 to return to previous model
    lbfgs_steps = 1000
    print_every = 1000
    batch_size = None
    
    # initial condition for the integration
    # IXa, Xa, II, IIa, VIIIa, APC, Va, Ia
    x_initial = [0.3, 1e-8, 1e-8, 1e-8, 1000, 1e-8, 1e-8, 6e-4, 1e-8]
    #k_index = [0, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 21, 22]
    #k_index = [0, 1, 2, 3, 4, 5, 9, 11, 12, 13, 19]  ##INCORRECT ## K INDICES ASSUMING ALL UNKNOWN STRUCTURAL IDENTIFIABILITY
    #k_index = [0, 1, 2, 3, 4, 5, 6, 9, 11, 12, 17, 18, 19, 20]  ##INCORRECT ## K INDICES ASSUMING SOME UNKNOWN STRUCTURAL IDENTIFIABILITY 
    #k_index = [6, 7, 8, 10, 14, 15, 16, 17, 18, 20, 21, 22] ## ASSUMING ALL UNKNOWN
    
    k_index = [16,18,20] ## ASSUMING SOME UNKNOWN
    
    #k_index = [7, 8, 10, 13, 14, 15, 16, 21, 22] ## ASSUMING SOME UNKNOWN W/O KNOWN EXP PARAMETER
    #k_index = [9]    
    # K  ----- rate constant change here

    k_list = [20, 0.2, 1, 0.31, 
              1.2, 0.17, 0.31, 3,
              24, 20, 1, 2.3,
              2.3, 3, 1, 2.3,
              1.3, 1.4, 0.1, 2.82,
              7.8, 0.2]
    #k_norm = [1, 1, 1, 1, 1,
    #          1, 1, 1, 1, 1e-6,
    #          1, 1e-6, 1e-8, 1, 1,
    #          1, 1, 1, 1, 1,
    #          1, 1, 1e5]
    # change here
    k_norm = [1, 1, 1e-5, 1,   
              1, 1, 1, 1e-3, 
              1, 1, 1, 1,
              1, 1e-3, 1, 1,
              1, 1e-3, 1, 1,
              1e-3, 1]
    # 11 coagulation factors - output them all
    x_index = [0,1,2,3,4,5,6,7,8]
    #x_index = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]

    data = RBCData()
    fnn = ln.nn.FNN(2, len(x_initial), depth, width, activation)
    net = RBCPINN(fnn, data.norm, k_index, k_list, k_norm, x_index, lam1 = 0.1, lam2 = 1)
    #net = torch.load('outputs/test1/model_best.pkl', map_location=torch.device('cpu'))
    #net.lam1 = 0.01
    
    path = 'test1'
    args = {
        'data': data,
        'net': net,
        'criterion': None,
        'optimizer': 'adam',
        'lr': lr,
        'iterations': iterations,
        'lbfgs_steps': lbfgs_steps,
        'batch_size': batch_size,
        'print_every': print_every,
        'save': True,
        'callback': callback,
        'path': path,
        'dtype': 'float',
        'device': device,
    }
    
    ln.Brain.Init(**args)
    ln.Brain.Run()
    ln.Brain.Restore()
    ln.Brain.Output()
    
    plot(data, ln.Brain.Best_model())
    #plot2(path)
    
if __name__ == '__main__':
    main()
