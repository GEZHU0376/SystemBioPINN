% coagulation model 1996 RAS

% ode45 solver
% initial condition IC
XIa = 0.3; % nM
IXa = 1e-8;
Xa = 1e-8;
IIa = 1e-8; % <- thrombin
II = 1000; % nM <- prothrombin
VIIIa = 1e-8;
Va = 1e-8;
APC = 6e-4;
Ia = 1e-8; % fibrin
Z = 1.125e-4;
W = 0.034;

% putting all initial condition into one variable
IC = [XIa IXa Xa IIa II VIIIa Va APC Ia Z W];


tspan = [0 100]; % 0 to 100 mins - time scale
options = odeset('NonNegative',1:11);
[t, y] = ode45(@ODEsystem,tspan,IC,options);
XIa = y(:,1);
IXa = y(:,2);
Xa = y(:,3);
IIa = y(:,4);
II = y(:,5);
VIIIa = y(:,6);
Va = y(:,7);
APC = y(:,8);
Ia = y(:,9);
Z = y(:,10); 
W = y(:,11);

figure
hold on
plot(t,IXa); 
plot(t,Xa);
plot(t,IIa);
plot(t,II);
plot(t,VIIIa);
plot(t,Va);
plot(t,APC);
plot(t,Ia);
legend('IXa', 'Xa', 'IIa', 'II', 'VIIIa', 'Va', 'APC', 'Ia')

function dydt = ODEsystem(t, y)
% kinetic constant for thrombin generation model
k9 = 20; % min.^-1
h9 = 0.2; % min.^-1
k8 = 0.00001; % min.^-1
h8 = 0.31; % min.^-1
ka = 1.2; % nM.^-1 min.^-1
k5 = 0.17; % min.^-1
h5 = 0.31; % min.^-1
k10 = 0.003;
kcat = 24; % min.^-1
km = 20; % nM
kd = 1; % nM
k2 = 2.3;
K2m = 2.3;
k10_catmax = 0.003; % min.^-1 or = 500
h10 = 1; % min.^-1
k2_catmax = 2.3; % min.^-1 or = 2000
h2 = 1.3; % min.^-1
k_apc = 0.0014; % min.^-1
h_apc = 0.1; % min.^-1
k1 = 2.82; % min.^-1
k11 = 0.0078; % min.^-1
h11 = 0.2; % min.^-1


XIa = y(1);
IXa = y(2); 
Xa  = y(3);
IIa = y(4);
II  = y(5);
VIIIa = y(6);
Va = y(7);
APC = y(8);
Ia = y(9);
Z = y(6)*y(2)/y(8); 
W = y(7)*y(3)/y(8);

% 8 ODEs 
dydt = zeros(size(y));
dydt(1) = -h11*XIa;
dydt(2) = k9*XIa - h9*IXa;
dydt(3) = k10*IXa + k10*Z - h10*Xa;
dydt(4) = k2*Xa*(II/(II+K2m)) + k2*W*(II/(II+K2m)) - h2*IIa;
dydt(5) = -k2*Xa*(II/(II+K2m)) - k2*W*(II/(II+K2m));
dydt(6) = k8*IIa - h8*VIIIa - ka*APC*(VIIIa+Z);
dydt(7) = k5*IIa - h5*Va - ka*APC*(Va+W);
dydt(8) = k_apc*IIa - h_apc*APC;
dydt(9) = k1*IIa;

disp(t)

end